import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { RoutePersistenceService } from '../../core/service/route-persistence.service';
import { StudentDataService } from '../../core/service/student-data.service';
import { Student } from '../../core/model/student';

@Component({
  selector: 'app-student-result',
  templateUrl: './student-result.component.html',
  styleUrls: ['./student-result.component.css']
})
export class StudentResultComponent implements OnInit, OnDestroy {

  activateLogoutBtn: boolean = false;

  studentForm: FormGroup = new FormGroup({
      roll_no: new FormControl(''),
      name: new FormControl(''),
      dob: new FormControl(''),
      score: new FormControl('')
  });

  constructor(private routePersistenceService: RoutePersistenceService, private route: ActivatedRoute, private studentDataService: StudentDataService, private location: Location, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      const roll_no = param['roll_no'];

      this.studentDataService.getStudent(roll_no).subscribe((student: any) => {
        this.fillForm(student);
      });
    });
    this.router.events.subscribe(() => {
      this.checkLogoutButton();
    })
  }

  fillForm(student: Student) {
    this.studentForm = new FormGroup({
      roll_no: new FormControl(student.roll_no),
      name: new FormControl(student.name),
      dob: new FormControl(student.dob),
      score: new FormControl(student.score.toFixed(1))
    });
  }

  gotoBack() {
    this.location.back();
  }

  checkLogoutButton(): void {
    if(this.routePersistenceService.getStudentLoggedIn() === "true" || this.routePersistenceService.getStudentLoggedIn() === "true") {
      this.activateLogoutBtn = true;
    }
    else {
      this.activateLogoutBtn = false;
    }
  }

 

  removeLogoutButton(): void {
    this.activateLogoutBtn = false;
  }

  ngOnDestroy(): void {
    this.removeLogoutButton();
  }
  onLogout() {
    this.routePersistenceService.clearRoutes();
    this.removeLogoutButton();
    this.router.navigateByUrl("/");
  }
}
