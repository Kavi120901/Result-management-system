export class Teacher {
    teacherId: string;
    password: string;

    constructor(teacherId: string, password: string) {
        this.teacherId = teacherId;
        this.password = password;
    }
}